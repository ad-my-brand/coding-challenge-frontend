package com.example.gitapp;

import static org.junit.Assert.*;

import org.junit.Test;

public class RepositoryAdapterTest {

    @Test
    public void getView() {
        String input;
        String output;
        getView();
    }
}