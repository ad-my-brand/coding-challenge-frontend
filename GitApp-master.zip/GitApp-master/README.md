# GitApp
Android application to search Github repositoires and issues, with simple and easy to understand UI.
